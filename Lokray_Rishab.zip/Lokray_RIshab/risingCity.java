//The main driver code, that takes the buildings from the heap and rbt and works on them for 5 days ta a time.

import java.io.*;
import java.util.*;

public class risingCity {

    int city_time = 0, building_time = 0, wait_time = 0;
    MinHeap minHeap;
    RedBlackTree rbt;
    FileWriter writer;

    public static void main(String[] args) throws Exception{
//        File file = new File(args[0]);
        Scanner sc = new Scanner(new File(args[0]));
        File writerFile = new File("output_file.txt");
        if(writerFile.exists())
            writerFile.delete();
//        Scanner sc = new Scanner(file);
        new risingCity().work(sc);
    }

     //Function to insert input to the data structures.
    public static void insertInput(MinHeap minHeap,RedBlackTree rbt, int building_no, int total_time){
        Node input = new Node(0, total_time, building_no);
        minHeap.insert(input); //executedtime,totaltime,buildingnumber //insert in heap
        rbt.put(input);  //Insert in RedBlackTree
    }
     //Function to write the output to file.
    public void write(String str) {
        try {
            writer = new FileWriter("output_file.txt", true);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);
            bufferedWriter.write(str);
            bufferedWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
 

    //Function to work on the main code of the file.   
    public void work(Scanner sc){
        minHeap = new MinHeap(2000);
        rbt = new RedBlackTree();
        ArrayList<String> inputSequence = new ArrayList<>();
        Node toworkon = null;


        while(sc.hasNextLine() || minHeap.size > -1 || inputSequence.size() > 0 || toworkon != null) {
//            System.out.println(city_time);
            while(wait_time <= city_time && sc.hasNextLine()) {
                String input = sc.nextLine();
//                System.out.println("Scanning input: " + input);
                wait_time = Integer.parseInt(input.split(":")[0]);
                inputSequence.add(input);
            }
            while(inputSequence.size() > 0) {
                String input = inputSequence.get(0);
                if (Integer.parseInt(input.split(":")[0]) > city_time)
                    break;
                input = inputSequence.remove(0);
                String requiredString = input.substring(input.indexOf("(") + 1, input.indexOf(")"));

                if (input.contains("Insert")) {
//                    System.out.println("Inserting input: " + param1 + "," + param2);
                    int param1 = Integer.parseInt(requiredString.split(",")[0]);
                    int param2 = Integer.parseInt(requiredString.split(",")[1]);
                    insertInput(minHeap, rbt, param1, param2);
//                    System.out.println("Heap: " + Arrays.toString(minHeap.Heap));
                } else {
                    if (input.contains(",")) {
                        int param1 = Integer.parseInt(requiredString.split(",")[0]);
                        int param2 = Integer.parseInt(requiredString.split(",")[1]);
                        rbt.print_range(param1, param2);
                    }
                    else {
                        int param1 = Integer.parseInt(requiredString.split(",")[0]);
                        rbt.print(param1);
                    }
                }
            }

            if(toworkon != null) {
                if(toworkon.etime == toworkon.tottime || building_time == 5) {
                    if(toworkon.etime == toworkon.tottime) {
                       rbt.remove(toworkon);
                        write("("+toworkon.bno+","+city_time+")\n");
//                        System.out.println("("+toworkon.bno+","+city_time+")");
                    }
                    else {
//                        System.out.println("Inserting into heap: " + toworkon.toString());
                        minHeap.insert(toworkon);
//                        System.out.println("Heap: " + Arrays.toString(minHeap.Heap));
                    }
                    building_time = 0;
                    toworkon = null;
                } else {
                    building_time = building_time + 1;
                    toworkon.etime = toworkon.etime + 1;
                }
            }

            if(minHeap.size > -1 && toworkon == null ) {
                toworkon = minHeap.remove();
                building_time = building_time + 1;
                toworkon.etime = toworkon.etime + 1;
            }
            city_time++;
//            if( city_time > 75) break;
        }
    }
}
