import java.util.Arrays;

//Min heap implementation that can help us pick the building with the least executed time and if same executed times choose the one with lower building time.
public class MinHeap {
    public Node[] Heap;  //Array of objects of type node.
    public int size;
    public int maximumsize;

    public static final int F = 0;

    public MinHeap(int maximumsize)
    {
        this.maximumsize = maximumsize;
        this.size = -1;
        Heap = new Node[this.maximumsize+1];
//        Heap[0] = new Node(0, 0, 0);
    }


    //parent position calculator
    private int parent(int position)
    {
        return (position-1) / 2;
    }

    //Left Child position calculator
    private int leftChild(int position)
    {
        return ((2 * position)+1);
    }

    //Right Child position calculator
    private int rightChild(int position)
    {
        return (2 * position) + 2;
    }

    //Check if leaf
    private boolean isitaLeaf(int position)
    {
        if (position > (size / 2) && position <= size) {
            return true; }
        return false;
    }

    // Function to swap nodes of the heap
    private void swap(int fposition, int sposition) {
        Node tmp = Heap[fposition];
        Heap[fposition] = Heap[sposition];
        Heap[sposition] = tmp;
    }

    // Function to heapify the node
    private void min_Heapify(int position)
    {

        if (!isitaLeaf(position)) {
            
            int initPos = position;
            if( (Heap[leftChild(position)] != null && Heap[leftChild(position)].etime <= Heap[position].etime)
                || (Heap[rightChild(position)] != null && Heap[rightChild(position)].etime <= Heap[position].etime)
            ) {
                if( Heap[leftChild(position)] != null &&
                        (Heap[leftChild(position)].etime < Heap[position].etime ||
                                (Heap[leftChild(position)].etime == Heap[position].etime && Heap[leftChild(position)].bno < Heap[position].bno))
                ) {
                    position = leftChild(position);
                }
                if( Heap[rightChild(initPos)] != null &&
                        (Heap[rightChild(initPos)].etime < Heap[position].etime ||
                                (Heap[rightChild(initPos)].etime == Heap[position].etime && Heap[rightChild(initPos)].bno < Heap[position].bno))
                ) {
                    position = rightChild(initPos);
                }
                if(position != initPos) {
                    swap(initPos, position);
                    min_Heapify(position);
                }

            }
        }
    }

    // Function to insert a node into the heap
    public void insert(Node input)
    {
        if (size >= maximumsize) {
            return;
        }

        int current = ++size;
        Heap[current] = input;
        while(current > 0 && (Heap[parent(current)].etime > Heap[current].etime ||
                (Heap[parent(current)].etime == Heap[current].etime && Heap[parent(current)].bno >= Heap[current].bno))
        ) {
            swap(current, parent(current));
            current = parent(current);
        }


        }




    //Function to extract the minimum element of the minheap
    public Node remove()
    {
        Node popped = Heap[F];
        Heap[F] = Heap[size];
        Heap[size--] = null;
        min_Heapify(F);
        return popped;
    }
    //Function to update the top most node and restructure the heap
    public void update(Node update){
        remove();
        insert(update);
        System.out.println("Heap: " + Arrays.toString(Heap));
    }
    //Function that simply returns the min element without deleting it from the tree.Used to extract minimum building that will be worked on for 5 days.
    public Node minimumelement()
    {
        Node pop = Heap[F];
        return pop;
    }

}