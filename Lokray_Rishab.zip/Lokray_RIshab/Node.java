//The basic structure of the node in a minheap
//The objects of this class hold executed time, Total time and Nuilding number.
public class Node{
    public int etime;
    public int tottime;
    public int bno;
    public Node(int x,int y,int z){
        etime = x;
        tottime = y;
        bno = z;
    }

    public String toString() {
        return "(" + bno + "," + etime + "," + tottime + ")";
    }
}