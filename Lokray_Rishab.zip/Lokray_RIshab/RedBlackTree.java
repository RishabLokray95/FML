//Red Black Tree code that helps in printing of the nodes.
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class RedBlackTree {
    private final int RED = 0;
    private final int BLACK = 1;
    private int counter = 0;

    public class Redblacknode {  //Red Black Node Class that acts as one Node object of the RBT.
        public Node received_building = new Node(0,0,0);
        public int colour = BLACK;
        public Redblacknode left = nil, right = nil, parent = nil;
        Redblacknode(Node received_building) {
            this.received_building = received_building;
        }
        public String toString() {
            return this.received_building.toString();
        }
    }

    private final Redblacknode nil = new Redblacknode(new Node(-1,-1,-1));
    private Redblacknode root = nil;
    

    //Function to find the particular redblacknode usig the building number.
    private Redblacknode findRedblacknode(Redblacknode findRedblacknode, Redblacknode redblacknode) {
        if (root == nil) {
            return null;
        }
        if (findRedblacknode.received_building.bno < redblacknode.received_building.bno) {
            if (redblacknode.left != nil) {
                return findRedblacknode(findRedblacknode, redblacknode.left);
            }
        } else if (findRedblacknode.received_building.bno > redblacknode.received_building.bno) {
            if (redblacknode.right != nil) {
                return findRedblacknode(findRedblacknode, redblacknode.right);
            }
        } else if (findRedblacknode.received_building.bno == redblacknode.received_building.bno) {
            return redblacknode;
        }
        return null;
    }

    //Function to insert the new incoming node
    private void insert(Redblacknode redblacknode) {
        Redblacknode temp = root;
        if (root == nil) {
            root = redblacknode;
            redblacknode.colour = BLACK;
            redblacknode.parent = nil;
        } else {
            redblacknode.colour = RED;
            while (true) {
                if (redblacknode.received_building.bno < temp.received_building.bno) {
                    if (temp.left == nil) {
                        temp.left = redblacknode;
                        redblacknode.parent = temp;
                        break;
                    } else {
                        temp = temp.left;
                    }
                } else if (redblacknode.received_building.bno >= temp.received_building.bno) {
                    if (temp.right == nil) {
                        temp.right = redblacknode;
                        redblacknode.parent = temp;
                        break;
                    } else {
                        temp = temp.right;
                    }
                }
            }
            fix_rbt_tree(redblacknode);
        }
    }

    //Function to fix the tree's red black tree properties when a new node is added
    private void fix_rbt_tree(Redblacknode redblacknode) {
        while (redblacknode.parent.colour == RED) {
            Redblacknode uncle = nil;
            if (redblacknode.parent == redblacknode.parent.parent.left) {
                uncle = redblacknode.parent.parent.right;

                if (uncle != nil && uncle.colour == RED) {
                    redblacknode.parent.colour = BLACK;
                    uncle.colour = BLACK;
                    redblacknode.parent.parent.colour = RED;
                    redblacknode = redblacknode.parent.parent;
                    continue;
                }
                if (redblacknode == redblacknode.parent.right) {
                    redblacknode = redblacknode.parent;
                    rotateLeft(redblacknode);
                }
                redblacknode.parent.colour = BLACK;
                redblacknode.parent.parent.colour = RED;
                //jibberish 
                rotateRight(redblacknode.parent.parent);
            } else {
                uncle = redblacknode.parent.parent.left;
                if (uncle != nil && uncle.colour == RED) {
                    redblacknode.parent.colour = BLACK;
                    uncle.colour = BLACK;
                    redblacknode.parent.parent.colour = RED;
                    redblacknode = redblacknode.parent.parent;
                    continue;
                }
                if (redblacknode == redblacknode.parent.left) {
                    redblacknode = redblacknode.parent;
                    rotateRight(redblacknode);
                }
                redblacknode.parent.colour = BLACK;
                redblacknode.parent.parent.colour = RED;
                rotateLeft(redblacknode.parent.parent);
            }
        }
        root.colour = BLACK;
    }

    //Helper function
    void rotateLeft(Redblacknode redblacknode) {
        if (redblacknode.parent != nil) {
            if (redblacknode == redblacknode.parent.left) {
                redblacknode.parent.left = redblacknode.right;
            } else {
                redblacknode.parent.right = redblacknode.right;
            }
            redblacknode.right.parent = redblacknode.parent;
            redblacknode.parent = redblacknode.right;
            if (redblacknode.right.left != nil) {
                redblacknode.right.left.parent = redblacknode;
            }
            redblacknode.right = redblacknode.right.left;
            redblacknode.parent.left = redblacknode;
        } else {
            Redblacknode right = root.right;
            root.right = right.left;
            right.left.parent = root;
            root.parent = right;
            right.left = root;
            right.parent = nil;
            root = right;
        }
    }

    //Helper Function
    void rotateRight(Redblacknode redblacknode) {
        if (redblacknode.parent != nil) {
            if (redblacknode == redblacknode.parent.left) {
                redblacknode.parent.left = redblacknode.left;
            } else {
                redblacknode.parent.right = redblacknode.left;
            }

            redblacknode.left.parent = redblacknode.parent;
            redblacknode.parent = redblacknode.left;
            if (redblacknode.left.right != nil) {
                redblacknode.left.right.parent = redblacknode;
            }
            redblacknode.left = redblacknode.left.right;
            redblacknode.parent.right = redblacknode;
        } else {//Need to rotate root
            Redblacknode left = root.left;
            root.left = root.left.right;
            left.right.parent = root;
            root.parent = left;
            left.right = root;
            left.parent = nil;
            root = left;
        }
    }
    
    //Helper Function
    void swap(Redblacknode target, Redblacknode with){
        if(target.parent == nil){
            root = with;
        }else if(target == target.parent.left){
            target.parent.left = with;
        }else
            target.parent.right = with;
        with.parent = target.parent;
    }

    //Funciton to delete the Node
    boolean delete(Redblacknode z){
        if((z = findRedblacknode(z, root))==null)return false;
        Redblacknode x;
        Redblacknode y = z;
        int y_original_colour = y.colour;

        if(z.left == nil){
            x = z.right;
            swap(z, z.right);
        }else if(z.right == nil){
            x = z.left;
            swap(z, z.left);
        }else{
            y = tree_Minimum(z.right);
            y_original_colour = y.colour;
            x = y.right;
            if(y.parent == z)
                x.parent = y;
            else{
                swap(y, y.right);
                y.right = z.right;
                y.right.parent = y;
            }
            swap(z, y);
            y.left = z.left;
            y.left.parent = y;
            y.colour = z.colour;
        }
        if(y_original_colour==BLACK)
            delete_rbt_fix(x);
        return true;
    }
    //Function to fix the Rbt properties after we delete.
    void delete_rbt_fix(Redblacknode x){
        while(x!=root && x.colour == BLACK){
            if(x == x.parent.left){
                Redblacknode w = x.parent.right;
                if(w.colour == RED){
                    w.colour = BLACK;
                    x.parent.colour = RED;
                    rotateLeft(x.parent);
                    w = x.parent.right;
                }
                if(w.left.colour == BLACK && w.right.colour == BLACK){
                    w.colour = RED;
                    x = x.parent;
                    continue;
                }
                else if(w.right.colour == BLACK){
                    w.left.colour = BLACK;
                    w.colour = RED;
                    rotateRight(w);
                    w = x.parent.right;
                }
                if(w.right.colour == RED){
                    w.colour = x.parent.colour;
                    x.parent.colour = BLACK;
                    w.right.colour = BLACK;
                    rotateLeft(x.parent);
                    x = root;
                }
            }else{
                Redblacknode w = x.parent.left;
                if(w.colour == RED){
                    w.colour = BLACK;
                    x.parent.colour = RED;
                    rotateRight(x.parent);
                    w = x.parent.left;
                }
                if(w.right.colour == BLACK && w.left.colour == BLACK){
                    w.colour = RED;
                    x = x.parent;
                    continue;
                }
                else if(w.left.colour == BLACK){
                    w.right.colour = BLACK;
                    w.colour = RED;
                    rotateLeft(w);
                    w = x.parent.left;
                }
                if(w.left.colour == RED){
                    w.colour = x.parent.colour;
                    x.parent.colour = BLACK;
                    w.left.colour = BLACK;
                    rotateRight(x.parent);
                    x = root;
                }
            }
        }
        x.colour = BLACK;
    }


    Redblacknode tree_Minimum(Redblacknode subTreeRoot){
        while(subTreeRoot.left!=nil){
            subTreeRoot = subTreeRoot.left; }
        return subTreeRoot;
    }

    public void write(String str) {
        try {
            FileWriter writer = new FileWriter("output_file.txt", true);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);
            bufferedWriter.write(str);
            bufferedWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //Funciton to search for  the range of nodes between two input buildign number and return it to the print funciton.
    public List<Node> printTreerange(Redblacknode redblacknode, Redblacknode redblacknode1,Redblacknode redblacknode2,List<Node> myList) {
        if (redblacknode == nil) {
            return myList;
        }
        printTreerange(redblacknode.left, redblacknode1, redblacknode2, myList);
        if(redblacknode.received_building.bno <= redblacknode2.received_building.bno && redblacknode.received_building.bno >= redblacknode1.received_building.bno) {
            myList.add(redblacknode.received_building);
        }
        printTreerange(redblacknode.right, redblacknode1, redblacknode2, myList);
        return myList;
    }

    //Helper Function to call the insert function
    public void put(Node temp){
        Redblacknode redblacknode = new Redblacknode(temp);
        insert(redblacknode);
    }
    //Helper function to call the delete funciton
    public void remove(Node temp){
        Redblacknode redblacknode = new Redblacknode(temp);
        delete(redblacknode);
    }

    //Funciton to print one single node.
    public void print(int bno){
        Node temp = new Node(0,0,bno);
        Redblacknode redblacknode = new Redblacknode(temp);
        Redblacknode output = findRedblacknode(redblacknode, root);
        if(output==null) {
             write("("+0+","+0+","+0+")\n");

        } else {

                write("(" + output.received_building.bno + "," + output.received_building.etime + "," + output.received_building.tottime + ")\n");

        }
    }

    //Takes the returned array list as input and from the Print tree rane funciton and prints output or (000) if node deos not exist.Rref
    public void print_range(int buildingno1,int buildingno2 ){
        counter = 0;
        inorder(root, buildingno1, buildingno2);
        if(counter == 0)
            write("(0,0,0)");
        write("\n");
 
    }

    public void inorder(Redblacknode currNode, int buildingno1, int buildingno2) {
        if(currNode == null)
            return;

        if( buildingno1 < currNode.received_building.bno)
            inorder(currNode.left, buildingno1, buildingno2);
        if( buildingno1 <= currNode.received_building.bno && currNode.received_building.bno <= buildingno2) {
            if(counter++ == 0)
                write("("+currNode.received_building.bno+","+currNode.received_building.etime+","+currNode.received_building.tottime+")");
            else
                write(",("+currNode.received_building.bno+","+currNode.received_building.etime+","+currNode.received_building.tottime+")");
        }
        if(currNode.received_building.bno < buildingno2)
            inorder(currNode.right, buildingno1, buildingno2);
    }
}


